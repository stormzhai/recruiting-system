webpackJsonp([18],{

/***/ 0:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(ReactDom, React) {'use strict';

	var GroupTitle = __webpack_require__(252);
	var ListGroup = __webpack_require__(258);
	var GroupEvent = __webpack_require__(253);
	var DiscussFrame = __webpack_require__(563);
	var Arrows = __webpack_require__(564);
	var AddPaper = __webpack_require__(565);
	var DiscussSubject = __webpack_require__(262);
	var DiscussList = __webpack_require__(566);
	var Paper = __webpack_require__(260);
	var AddSection = __webpack_require__(567);
	var Table = __webpack_require__(568);
	var InviteLink = __webpack_require__(569);
	var PageMachine = __webpack_require__(570);
	var GroupAvatar = __webpack_require__(255);
	var UploadAvatar = __webpack_require__(571);
	var LectureButton = __webpack_require__(572);
	var CompleteSection = __webpack_require__(573);
	var LockSection = __webpack_require__(574);
	var AddGroup = __webpack_require__(575);
	var TextBox = __webpack_require__(256);

	__webpack_require__(576);
	__webpack_require__(578);
	__webpack_require__(580);
	__webpack_require__(582);
	__webpack_require__(584);
	__webpack_require__(586);
	__webpack_require__(588);
	__webpack_require__(590);
	__webpack_require__(592);
	__webpack_require__(594);
	__webpack_require__(578);
	__webpack_require__(596);
	__webpack_require__(598);
	__webpack_require__(600);
	__webpack_require__(602);
	__webpack_require__(604);
	__webpack_require__(606);

	ReactDom.render(React.createElement(
	  'div',
	  null,
	  React.createElement(GroupTitle, null),
	  React.createElement(ListGroup, null),
	  React.createElement(GroupEvent, null),
	  React.createElement(DiscussFrame, null),
	  React.createElement(Arrows, null),
	  React.createElement(DiscussSubject, null),
	  React.createElement(DiscussList, null),
	  React.createElement(Paper, { item: '' }),
	  React.createElement(AddPaper, null),
	  React.createElement(Table, null),
	  React.createElement(InviteLink, null),
	  React.createElement(PageMachine, null),
	  React.createElement(GroupAvatar, null),
	  React.createElement(AddGroup, null),
	  React.createElement(UploadAvatar, null),
	  React.createElement(LectureButton, null),
	  React.createElement(AddSection, null),
	  React.createElement(CompleteSection, null),
	  React.createElement(LockSection, null),
	  React.createElement(TextBox, null)
	), document.getElementById('style-guide'));
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(19), __webpack_require__(165)))

/***/ },

/***/ 252:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = React.createClass({
	  displayName: 'GroupTitle',


	  getInitialState: function getInitialState() {
	    return {
	      titleName: this.props.titleName || '群组首页'
	    };
	  },
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'group-title' },
	      React.createElement(
	        'h4',
	        null,
	        this.state.titleName
	      ),
	      React.createElement('hr', null)
	    );
	  }
	});

	module.exports = GroupTitle;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 253:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupEvent = React.createClass({
	  displayName: 'GroupEvent',


	  getInitialState: function getInitialState() {
	    return {
	      items: [{
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'user',
	        time: '04/01/2016 10:22',
	        action: '发布了一条评论',
	        content: '这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难'
	      }, {
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'admin',
	        time: '04/01/2016 10:22',
	        action: '增加了一张新试卷 《面向对象 Step By Step》',
	        content: ''
	      }, {
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'user',
	        time: '04/01/2016 10:22',
	        action: '加入了群组',
	        content: ''
	      }, {
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'user',
	        time: '04/01/2016 10:22',
	        action: '完成了试卷《集合运算》',
	        content: ''
	      }]
	    };
	  },

	  render: function render() {

	    var eventList = this.state.items.map(function (item, index) {
	      return React.createElement(
	        'div',
	        { className: 'col-md-12 col-sm-12 col-xs-12 group-event', key: index },
	        React.createElement(
	          'h5',
	          null,
	          React.createElement(
	            'div',
	            { className: 'user-avatar' },
	            React.createElement('img', { src: item.avatar })
	          ),
	          React.createElement(
	            'div',
	            { className: 'event-info' },
	            React.createElement(
	              'em',
	              null,
	              item.type === 'admin' ? '管理员:' : ''
	            ),
	            item.name,
	            React.createElement(
	              'small',
	              null,
	              item.time
	            ),
	            React.createElement(
	              'span',
	              null,
	              item.action
	            )
	          )
	        ),
	        item.content !== '' ? React.createElement(
	          'p',
	          { className: 'col-md-2 col-sm-4 col-xs-6' },
	          React.createElement(
	            'a',
	            { href: '#' },
	            item.content
	          )
	        ) : null,
	        React.createElement('hr', { className: 'col-md-12 col-sm-12 col-xs-12' })
	      );
	    });

	    return React.createElement(
	      'div',
	      null,
	      eventList
	    );
	  }
	});

	module.exports = GroupEvent;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 254:
/***/ function(module, exports) {

	module.exports = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCACOAJEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6joooqSQooooAY33ao6lf2ml2cl3fzx29tH9+SStCvJvGaP4o+IFloUb/APEu0yP7ZfJ/00k/1dZ1J+zgVE7Xw34s0PxJ5v8AYup214Y/9Ykb/PHXSV87+ILKODxr/wASmeTT9egt/tEF5H/y0j/55yf89K9P+HfjBPElpc2t9B9j1mz/AHd3bfl88fP+rrnw+IVT3SqlP2Z3VFFFdhmFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADT0ryn4Wv9uTXtdfiTU7+ST/ALZ/6uOu18cX39meDda1BB81vaSSR/8AfFcr8P4oND8BW3mSfu4I/wB5XDX+OMTSmcn8TY/7P1K212P/AJcLj/SP+veT/WVjeJ9Rh0LULLXbC7jj1m3/ANXH/wA/cf8Ay0jqidO/4THXdR1W8kkj0afzLeOO3kkj+0R/89K6+1t47eOOOP8A5Zx+XXkYjEU6dXmpnoU6f7s6a0+L3hqeCN5P7Rjkdfnj+wXH7v8A8h1aHxW8IH/j41UWn/XxDJHWJFol9Jb+ZsrOlj8z/WVq84nT+KJn9UpnqOka7pWrx7tL1SzvP+vW4jkraJPbpXgdz4f0ef8A1lhbxyf89I4/Lk/7+VJJqPjDRtMuIPDusR3n7v8Adx6p+8kj/wCucn/xyuihnFOp8RnUwdRHqfinxTpHha3WTU7vZJJ/q7eP5pJP+ucdedal458VaqkcejWtv4fjkk8uOTUB59xJ/wBs657TrSy0uxk1nU3kkvXj8y4vLyTzJK0/AGlz6x4hj13UreS3jjj/ANAt5P8AlnH/AM9JP+mklP65UrP92H1enT/iHU+DNf1eDxGvh/xHdJdXElv9ot7iOPy2/d/6yOSvUB92vLNVj/4vJ4Rf/p3vP/Rdepj7td+H/hnNMWiiiuggKKKKACiiigAooqOWRIYy7sFQUAcj8Vtn/CufEW9tn+gyc+leZ6Jqc+seGvsl9pvl6dJHH/x8f6ySrfivV08a6zbwWknmeHNOk8x5M/u7u4/+Nx1N9K+bzTEe/wCzpnpYOmYOr+J4NHuPsn9mapcf9e9pJJHWSfibpumzRz3lhqlnHHJ/rLi0kr2Dwz4p8OW9lHYz61p6Xtuv7yOS4j8yOrOu+IPBGqaXLaa1q2h3FnJ/rI5rmOuvD5XTqQ9oRUxFQyvBXxD8N+Lf3ejX0cl75fmfZ5P3clUdfjjj1e58v/npVGO88KSW9uPBSWn2e08yPzLOP92Kj/DFefmVT/l2aYen/wAvDo/C2lx3EclxcR+Z/wAs446TxNpsFnHHPbx+Xv8A+WdZUeqalBp8tpptxHbyv/q5JE8zy6xda8IfE+D9/HrGk6x/0zkj8unh8PTxGH9nTHUqezqfvCl4t0P+3NNj8t5I5IJPtEccf/LST/ppXT/B/U77VdFlfVnjkvY5PLkk8jy/LkryvQviNf3F/cWGreHtQt7mD/j48uPzPLr0zwRJHod9q3mSf6Fcf6RHH/00/wCWlaYf2mC/d1gqfvf3lM0rd1vPjTabj/x4aZJIv/bSSOOvVq8k+FkcmoeNfE2s8GCMx2Sf9dP9ZJ/6Mr1uvZwf8M86puFFFFdZAUUUUAFFFFADf4K88+K/iCPR9Hg037D9svdW/wBDt45I/Mj/AO2leiL0rx342W/leIfBl9C7xTfa5LV8Sf8ALPy/M/8AadZ1JcsTSkvfNfwB4Xg0TRLeBI4/Ljj+T93XV3NvHJH5ckf7qotM/eafbv8A9M6uLxXl06fNTOioeSeKPhZY6neSzyWkdx/00riW+E1pDdfvz5cf/TO0jjr6RxxRjPes/YVP+Xcg5zyDRNMtNIs/Is4/Ljq5zXIfHbx7/wAIXr9vY6TYxyXM8fmSeZ/q64GL4x6zbvvvNGs5Iv8AphJXF/ZOIkdn1yme2yeZ5f7v/Wf8s6h8NfGmCPzLTxfptxZ3Vv8Au5J7eMvHn/rn/rErH+Guq23xNt79I1vNLuLD/nnJ/q5K0bXwr/wlVtc/2gkf9o2E8llJJH+7krXB062C0ZnU9nUOstviz4Juvktdet5JpP8Aln5cnmNXJ63p/wDaml3Npv8AL8z/AFcn/POStHRPh3/Z/lmTy5JI/wDl4k/1ldLqXhuOOz8yx8zzY/8AyJVYz2uI/eKIqXs6RH8DUij+HumC3k8yT959pkk/1jXHmfvK9HNeQ/CfUYNP8Q614bkkj8yST+0II/8Arp/rK9fr2sPU9pA8+puFFFFdBAUUUUAFFFFABXmnxuiUeF7fUiiSHS7yO8/7Z/6uT/0ZXpVUdU06DVNPubG8QSW08flyL/erOavoBgeH5I5NFt/L/wCedaZ71598Lbiezj1Hw3qT/wDEx0eTy/8ArpH/AMs5P+/degnvXn0/4ZvUFooorYZ86ftJfDrUtf1KPXdGT7Q0cflyQV83f8I/rX2jyP7Iv/OH/LPyHr9FfL8z/WVGLeCP/lhHWtOuZ+zPGf2avA2peFdL1K+1qH7Pc3/l+XB/y0WOu98GyeZ4q8bSR/6r7fHH/wBtPLjroPEGqJo+k3F3/wA84/3f7ys34f6PcaPoP/Eykjk1K7kkvLjy/wDnpJWUveNDpqKKglkSOOWST/Vx0Aecwyabpvxms0ktd9xf28kcEmzzPs8kf/7yvZWrxX4a2MniTx5q3iS4ubj7JY3H2eyjjk/dySeX+8r2mtsL/DM5/EPoooroMwooooAKKKKACiiigDzD4g+H7+01K38V+HIGuNStI/Lu7Nf+Xy39P9+uh8Paxaa5pMd/psnmRyf+Q6b478VQ+FtI88R/bNQuP3dpZx9Z5K8UsLXxbZ6vc+ILfU0j1W7k8y4t/L/0OT/tn/7Urz8RUp0/4h0U6dSpsfQPaqmpTz29v5lvb+ZJWF4N8QT63byf2lYf2fex/wDLPzPMjk/6511Has/4gHhV5qnxi1WSR7XRY9Ltv+Wcf7vzP/RlZdzpfxek/wBZPef9s7i3r6CuY/Mj8vzPLqn9gf8A5/JPyrU09oeLeDfD+v6xrVzofxGv9aj8yPzLe38yPy54/wDlp/q691ij8uPZHUcWn2keoSX/AJEf22SPy/M/6Z0Xt5aafH5l9cR28f8Az0kk8ukZlojAxXn3jrXJ7q8tvDfh795q13/5Lx/89JKp6v8AEB9fuJNJ8AW8msXv+rkuI/8Aj3j/AOukldl4E8I2/hm1nmmk+2azd/8AH3eSf8tP/saVOnzB7T2ZteFtFtPDuh2em2IHlQR/99f7VblFFeic4UUUUAFFFFABRRXG/EXxOPCnh37asfmXE9xHaQRv/wA9JKAOveVE+8cVn3OrafbxyPNeQL5a7m/eV5l4aj8OeLZ7n+0NSk8SajayfvPtH7uOP/rnH/q6r+LPh/4fj/fw6Lp/lyf6yPy65MRiPZ0+Y0p0/aGTa3cnifVZfEl9/wAt/wB3YR/8+9v/APbK0jzUVjbwWdvHBZxx28cf+rjjqlq+sJZ3FtaW8f2jUbiTy47f/wBqV8pUqVMTUPYpfu6Z0XhuN5NTjeP/AJZ/6yvQRxVDTLJLO38uOtDtmvaweH9lTOOdT2gUUUV3HOZXiHS49YsJIJHuI/8Ann5dxJH/AOi68fuPBekyXBe4g+0SR/8APxJ5n/oyvdR0HrXn3iS3+z6rJ/t/vK8vMHU9n7SmdGHOV0yC78H38uq+Hk8yN/8Aj70//lncR/8ATP8A6aV7boOsWmt6RbalpsvnWVxH5kcleVSj939/y6x9L8MJEDaSXd5cRTz+ZJHJceXH5kn/AEzjrLB5p7On7OoaYjD+0/hnvEWoWsn+ruYG/wC2gq4K84vfDfhLR9JlnvtE02O2gj/eSfZ65vSvGFhpVzH/AGHqMl5o37v7RaXHmSeRHJJ5fmRyf+069+nUPO9me2UUUV0EBRRRQAV5r8b9DuNV8JRy2nniWxu47r/Rz+88sf6yvSqKAPnLwJb6B4fjk1ix1iz+0yR/vJPtH7uP/tnWhd+JvFGqySPaeHtTutF8v/RZI4P9Z/00r1+Tw5oU98t5caLYSXv/AD1kt499b1c9TD06hp7Q+fodP8XarM9tb6Bdafv58+7WMRpVX4R6LHb+Kb2e6k+2Xv2u4jkuJP8Alp5f7uvojoK8I+DRw8skn+t+0XHmf9/JK87EYeOG5fZm9OpUqHsFFFFdZAUUUUAIO1ef/FbT7/8As+PVtJ/eSWn+st/+fiOvQB2rH8Ux+Z4dvf8ArnWNT+GFM8l0TxJaapb+ZHJ/10/6Z1fk8SaXp8kckk8fmR/8s6X4X+CvD/iSPxFdazpsdxcx6n5fmF5I/wDlnHXqXh/wP4b0GTzNH0aztpB/y0WP95XHTyeMv3h0fXDyvxl4jg8UaDLYalb6l4f8z/j3kvI/L+11h/CzTrvVZ7bSdPcyaSnlyX8g/wCXfy5PM8vzP+WnmV9H31nb3kPl3cEU0f8Adkj30ljZ21na+VZ28cEXZI08uvZ9mcftC7RRRW5mFFFFABRRRQAUUUUAJ1FcN4a8DwaHql7d293JILi4kuPL2/c8yu6orOpTU9wM/wDs8/8APQ0f2ef+ehq9u9qTcafskHtCl/Z/+2aP7P8A9s1cp272o9jEPaFD7Ef74qvqWlfbLC4t9/l+ZH5dbNFL2cS/aM5LwL4Tj8LWl7FHcfaPtdz9o3ba62iitCAooooAKKKKACiiigD/2Q=="

/***/ },

/***/ 255:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupAvatar = React.createClass({
	  displayName: 'GroupAvatar',


	  getInitialState: function getInitialState() {
	    return {
	      groupName: this.props.groupName || '前端学习群',
	      groupAvatar: this.props.groupAvatar || ''

	    };
	  },

	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'col-md-12 col-sm-12 col-xs-12 text-center' },
	      React.createElement(
	        'div',
	        { className: 'avatar' },
	        React.createElement(
	          'a',
	          { href: '#' },
	          this.state.groupAvatar !== '' ? React.createElement('img', { src: this.state.groupAvatar }) : React.createElement(
	            'span',
	            null,
	            React.createElement('i', { className: 'fa fa-group' })
	          )
	        )
	      ),
	      React.createElement(
	        'div',
	        { className: 'avatar-name' },
	        React.createElement(
	          'a',
	          { href: '#' },
	          this.state.groupName
	        )
	      )
	    );
	  }
	});

	module.exports = GroupAvatar;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 256:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var TextBox = React.createClass({
	  displayName: 'TextBox',


	  getInitialState: function getInitialState() {
	    return {
	      content: this.props.content
	    };
	  },

	  render: function render() {
	    return React.createElement('textarea', { className: 'textarea',
	      value: this.state.content,
	      readOnly: this.props.readonly ? 'readonly' : '' });
	  }
	});

	module.exports = TextBox;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 258:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = React.createClass({
	  displayName: 'ListGroup',


	  getInitialState: function getInitialState() {
	    return {
	      title: '个人中心',
	      list: ['群组首页', '群组试卷', '群组成员', '群组管理'],
	      clickNumber: 1
	    };
	  },

	  handleClick: function handleClick(clickNumber) {
	    this.setState({
	      clickNumber: clickNumber
	    });
	  },

	  render: function render() {
	    var _this = this;

	    var listContent = this.state.list.map(function (item, index) {
	      var classStr = "list-group-item " + (_this.state.clickNumber === index + 1 ? 'select' : '');
	      return React.createElement(
	        'button',
	        { className: classStr, key: index, onClick: _this.handleClick.bind(null, index + 1) },
	        React.createElement(
	          'div',
	          { className: 'row' },
	          React.createElement(
	            'div',
	            { className: 'h4 text-center' },
	            item
	          )
	        )
	      );
	    });

	    return React.createElement(
	      'div',
	      null,
	      React.createElement(
	        'div',
	        { className: 'list-group' },
	        React.createElement(
	          'div',
	          { className: 'list-group-item active' },
	          React.createElement(
	            'div',
	            { className: 'row' },
	            React.createElement(
	              'div',
	              { className: 'h4 text-center' },
	              this.state.title
	            )
	          )
	        ),
	        listContent
	      )
	    );
	  }
	});
	module.exports = ListGroup;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 260:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var Paper = React.createClass({
	  displayName: 'Paper',
	  getInitialState: function getInitialState() {
	    return {
	      paperName: this.props.item.paperName || 'PaperNamePaperName',
	      isMarked: this.props.item.isMarked,
	      isPublished: this.props.item.isPublished,
	      sectionNumber: this.props.item.sectionNumber || 10,
	      publishedNumber: this.props.item.publishedNumber || 1,
	      role: this.props.item.role || '2',
	      isFinished: this.props.item.isFinished
	    };
	  },

	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'paper-button col-xs-12' },
	      React.createElement(
	        'h3',
	        { className: 'paper-name col-xs-9' },
	        this.state.paperName
	      ),
	      React.createElement(
	        'div',
	        { className: 'col-xs-3' },
	        React.createElement('i', { className: "fa fa-2x" + (this.state.isMarked ? ' fa-star' : ' fa-star-o') })
	      ),
	      React.createElement(
	        'div',
	        { className: "col-md-9 col-sm-5" + (this.state.role === '1' ? '' : ' hide') },
	        React.createElement(
	          'div',
	          { className: this.state.isPublished ? 'hide' : '' },
	          '未发布：',
	          React.createElement(
	            'a',
	            { href: '#' },
	            '点击发布'
	          )
	        ),
	        React.createElement(
	          'div',
	          { className: this.state.isPublished ? '' : ' hide' },
	          '已发布'
	        ),
	        React.createElement(
	          'div',
	          null,
	          '章节个数：',
	          this.state.sectionNumber
	        ),
	        React.createElement(
	          'div',
	          null,
	          '已发布个数：',
	          this.state.publishedNumber
	        )
	      ),
	      React.createElement(
	        'div',
	        { className: 'button-bottom' },
	        React.createElement(
	          'a',
	          { href: '#', className: "text-warning" + (this.state.role === '1' ? '' : ' unvisible') },
	          React.createElement(
	            'b',
	            null,
	            '编辑'
	          )
	        ),
	        React.createElement(
	          'a',
	          { href: '#', className: "text-info" + (this.state.role === '1' ? '' : ' unvisible') },
	          React.createElement(
	            'b',
	            null,
	            '导出成绩'
	          )
	        ),
	        React.createElement(
	          'a',
	          { href: '#', className: "text-success" + (this.state.isFinished ? ' unvisible' : '') },
	          React.createElement(
	            'b',
	            null,
	            '开始答题'
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = Paper;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 262:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var DiscussSubject = React.createClass({
	  displayName: 'DiscussSubject',

	  getInitialState: function getInitialState() {
	    return {
	      subjectList: [{
	        isMe: true,
	        userName: '某某某',
	        time: '04/01/2016 10:22',
	        subject: '阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科'
	      }, {
	        isMe: false,
	        userName: '某某某',
	        time: '04/01/2016 10:22',
	        subject: '阿里的罚金老师的罚款了世界的科'
	      }]
	    };
	  },
	  render: function render() {

	    var subjectList = this.state.subjectList.map(function (item, index) {
	      var operateCls = "operate col-md-2 col-sm-2 col-xs-2" + (item.isMe ? '' : ' unvisible');
	      return React.createElement(
	        'div',
	        { className: 'discuss-subject col-md-12 col-sm-12 col-xs-12', key: index },
	        React.createElement(
	          'div',
	          { className: 'content col-md-10 col-sm-10 col-xs-10' },
	          React.createElement(
	            'h5',
	            { className: 'col-md-12 col-sm-12 col-xs-12' },
	            item.isMe ? '我' : item.userName,
	            React.createElement(
	              'small',
	              null,
	              item.time
	            )
	          ),
	          React.createElement(
	            'p',
	            { className: 'col-md-10 col-sm-9 col-xs-6' },
	            React.createElement(
	              'a',
	              null,
	              item.subject
	            )
	          )
	        ),
	        React.createElement(
	          'div',
	          { className: operateCls },
	          React.createElement(
	            'a',
	            { href: '#' },
	            '编辑'
	          ),
	          React.createElement(
	            'a',
	            { href: '#' },
	            '删除'
	          )
	        ),
	        React.createElement('hr', { className: 'col-md-12 col-sm-12 col-xs-12' })
	      );
	    });
	    return React.createElement(
	      'div',
	      null,
	      subjectList
	    );
	  }
	});

	module.exports = DiscussSubject;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 563:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var DiscussFrame = React.createClass({
	  displayName: 'DiscussFrame',

	  getInitialState: function getInitialState() {
	    return {
	      isContent: true
	    };
	  },
	  changeState: function changeState(mark) {
	    if (mark === 'content') {
	      this.setState({ isContent: true });
	    } else {
	      this.setState({ isContent: false });
	    }
	  },

	  render: function render() {
	    return React.createElement(
	      'form',
	      { className: 'form-horizontal col-md-12 col-sm-12 col-xs-12' },
	      React.createElement(
	        'div',
	        { className: 'discuss-part' },
	        '主题:',
	        React.createElement('input', { className: 'form-control', type: 'text', placeholder: '请输入主题' })
	      ),
	      React.createElement(
	        'div',
	        { className: 'discuss-type' },
	        React.createElement(
	          'div',
	          { className: "discuss-item" + (this.state.isContent ? ' label label-primary' : ''),
	            onClick: this.changeState.bind(null, 'content') },
	          '内容'
	        ),
	        React.createElement(
	          'div',
	          { className: "discuss-item" + (this.state.isContent ? '' : ' label label-primary'),
	            onClick: this.changeState.bind(null, 'preview') },
	          '预览'
	        )
	      ),
	      React.createElement(
	        'div',
	        { className: 'discuss-frame' },
	        React.createElement('span', { className: "discuss-arrow" + (this.state.isContent ? '' : ' preview') }),
	        React.createElement('textarea', { className: 'discuss-textarea' }),
	        React.createElement(
	          'div',
	          { className: 'discuss-button' },
	          React.createElement(
	            'a',
	            { href: '#' },
	            '发布'
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = DiscussFrame;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 564:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var Arrows = React.createClass({
	  displayName: "Arrows",

	  render: function render() {
	    return React.createElement("i", { className: "fa fa-arrow-circle-down fa-5x text-primary" });
	  }
	});

	module.exports = Arrows;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 565:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var AddPaper = React.createClass({
	  displayName: "AddPaper",

	  render: function render() {
	    return React.createElement(
	      "div",
	      { className: "paper-button col-xs-12 text-center" },
	      React.createElement("i", { className: "fa fa-plus text-primary fa-5x" })
	    );
	  }
	});

	module.exports = AddPaper;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 566:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var DiscussList = React.createClass({
	  displayName: 'DiscussList',

	  getInitialState: function getInitialState() {
	    return {
	      discussionList: [{
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        time: '04/01/2016 10:22',
	        discussion: '这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难'
	      }, {
	        avatar: '',
	        name: '李煜',
	        time: '04/01/2016 10:22',
	        discussion: '这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难'
	      }]
	    };
	  },
	  render: function render() {
	    var discussionList = this.state.discussionList.map(function (item, index) {
	      return React.createElement(
	        'div',
	        { className: 'col-md-12 col-sm-12 col-xs-12 group-event', key: index },
	        React.createElement(
	          'h5',
	          null,
	          React.createElement(
	            'div',
	            { className: 'user-avatar' },
	            item.avatar !== '' ? React.createElement('img', { src: item.avatar }) : React.createElement(
	              'span',
	              null,
	              React.createElement('i', { className: 'fa fa-user' })
	            )
	          ),
	          React.createElement(
	            'div',
	            { className: 'event-info' },
	            item.name,
	            React.createElement(
	              'small',
	              null,
	              item.time
	            )
	          )
	        ),
	        React.createElement(
	          'p',
	          { className: 'col-md-2 col-sm-4 col-xs-6 discuss' },
	          item.discussion
	        ),
	        React.createElement('hr', { className: 'col-md-12 col-sm-12 col-xs-12' })
	      );
	    });
	    return React.createElement(
	      'div',
	      null,
	      discussionList
	    );
	  }
	});
	module.exports = DiscussList;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 567:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var AddSection = React.createClass({
	  displayName: "AddSection",

	  render: function render() {
	    return React.createElement(
	      "div",
	      { className: "dashboard-icon col-md-12 col-sm-12 col-xs-12" },
	      React.createElement(
	        "div",
	        { className: "icon col-md-12 col-sm-12 col-xs-12" },
	        React.createElement(
	          "div",
	          { className: "icon-img icon-add" },
	          React.createElement("span", { className: "fa fa-plus" })
	        )
	      )
	    );
	  }
	});

	module.exports = AddSection;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 568:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var Table = React.createClass({
	  displayName: 'Table',

	  getInitialState: function getInitialState() {
	    return {
	      tableList: [{
	        firstName: 'Mark',
	        lastName: 'Otto',
	        userName: '@mdo'
	      }, {
	        firstName: 'Jacob',
	        lastName: 'Thornton',
	        userName: '@fat'
	      }, {
	        firstName: 'Larry',
	        lastName: 'the Bird',
	        userName: '@twitter'
	      }]
	    };
	  },
	  render: function render() {
	    var tableList = this.state.tableList;
	    var list = tableList.map(function (item, index) {
	      return React.createElement(
	        'tr',
	        { key: index },
	        React.createElement(
	          'th',
	          { scope: 'row' },
	          index + 1
	        ),
	        React.createElement(
	          'td',
	          null,
	          item.firstName
	        ),
	        React.createElement(
	          'td',
	          null,
	          item.lastName
	        ),
	        React.createElement(
	          'td',
	          null,
	          item.userName
	        )
	      );
	    });
	    return React.createElement(
	      'table',
	      { className: 'table table-hover' },
	      React.createElement(
	        'thead',
	        null,
	        React.createElement(
	          'tr',
	          null,
	          React.createElement(
	            'th',
	            null,
	            '#'
	          ),
	          React.createElement(
	            'th',
	            null,
	            'First Name'
	          ),
	          React.createElement(
	            'th',
	            null,
	            'Last Name'
	          ),
	          React.createElement(
	            'th',
	            null,
	            'Username'
	          )
	        )
	      ),
	      React.createElement(
	        'tbody',
	        null,
	        list
	      )
	    );
	  }
	});

	module.exports = Table;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 569:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var InviteLink = React.createClass({
	  displayName: 'InviteLink',
	  getInitialState: function getInitialState() {
	    return {
	      inviteLink: 'https://github.com/wengjiaojiao'
	    };
	  },
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'invite-link col-md-12 col-sm-12 col-xs-12' },
	      React.createElement(
	        'p',
	        { className: 'col-md-2 col-sm-2 col-xs-4 text-right' },
	        '邀请链接:'
	      ),
	      React.createElement(
	        'div',
	        { className: 'col-md-4 col-sm-6 col-xs-8' },
	        React.createElement(
	          'div',
	          { className: 'input-group' },
	          React.createElement('input', { type: 'text', className: 'form-control', value: this.state.inviteLink, readOnly: true }),
	          React.createElement(
	            'span',
	            { className: 'input-group-btn' },
	            React.createElement(
	              'button',
	              { className: 'btn btn-default', type: 'button' },
	              '复制'
	            )
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = InviteLink;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 570:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var PageMachine = React.createClass({
	  displayName: "PageMachine",

	  getInitialState: function getInitialState() {
	    return {
	      pageList: [1, 2, 3, 4, 5]
	    };
	  },
	  render: function render() {
	    var pageList = this.state.pageList;
	    var list = pageList.map(function (item, index) {
	      return React.createElement(
	        "li",
	        { key: index },
	        React.createElement(
	          "a",
	          { href: "#" },
	          item
	        )
	      );
	    });

	    return React.createElement(
	      "nav",
	      null,
	      React.createElement(
	        "ul",
	        { className: "pagination" },
	        React.createElement(
	          "li",
	          null,
	          React.createElement(
	            "a",
	            { href: "#", "aria-label": "Previous" },
	            React.createElement(
	              "span",
	              { "aria-hidden": "true" },
	              "«"
	            )
	          )
	        ),
	        list,
	        React.createElement(
	          "li",
	          null,
	          React.createElement(
	            "a",
	            { href: "#", "aria-label": "Next" },
	            React.createElement(
	              "span",
	              { "aria-hidden": "true" },
	              "»"
	            )
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = PageMachine;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 571:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var UploadAvatar = React.createClass({
	  displayName: 'UploadAvatar',
	  getInitialState: function getInitialState() {
	    return {
	      avatar: ''
	    };
	  },
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'upload-avatar col-md-12 col-sm-12 col-xs-12' },
	      React.createElement(
	        'div',
	        { className: 'avatar' },
	        this.state.avatar !== '' ? React.createElement('img', { src: this.state.avatar }) : React.createElement(
	          'span',
	          null,
	          React.createElement('i', { className: 'fa fa-user' })
	        )
	      ),
	      React.createElement(
	        'div',
	        { className: 'upload' },
	        React.createElement(
	          'span',
	          null,
	          React.createElement(
	            'a',
	            { href: '#' },
	            React.createElement('i', { className: 'fa fa-camera' }),
	            '修改头像'
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = UploadAvatar;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 572:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var LectureButton = React.createClass({
	  displayName: 'LectureButton',

	  getInitialState: function getInitialState() {
	    return {
	      isPublished: false,
	      role: 1,
	      lecture: 'logic'
	    };
	  },

	  render: function render() {
	    var lecture = {
	      logic: {
	        title: '逻辑题',
	        icon: 'fa fa-codepen'
	      },
	      homework: {
	        title: '编程题',
	        icon: 'fa fa-code'
	      }
	    };
	    return React.createElement(
	      'div',
	      { className: 'dashboard-icon col-md-12 col-sm-12 col-xs-12' },
	      React.createElement(
	        'div',
	        { className: 'icon col-md-12 col-sm-12 col-xs-12' },
	        React.createElement(
	          'div',
	          { className: 'icon-img' },
	          React.createElement('span', { className: lecture[this.state.lecture].icon })
	        ),
	        React.createElement(
	          'p',
	          { className: 'icon-name' },
	          lecture[this.state.lecture].title
	        ),
	        React.createElement(
	          'div',
	          { className: 'icon-bottom col-md-12 col-sm-12 col-xs-12' },
	          React.createElement(
	            'div',
	            { className: "col-md-4 col-sm-4 col-xs-3 text-left" + (this.state.isPublished ? ' text-success' : ' text-danger') },
	            this.state.isPublished ? '已发布' : '未发布'
	          ),
	          React.createElement(
	            'div',
	            { className: "published-option col-md-8 col-sm-8 col-xs-9 text-right" + (this.state.role === 1 ? '' : ' hide') },
	            React.createElement(
	              'a',
	              { href: '#', className: 'published' },
	              '发布'
	            ),
	            React.createElement(
	              'a',
	              { href: '#', className: 'edit' },
	              '编辑'
	            ),
	            React.createElement(
	              'a',
	              { href: '#', className: 'delete' },
	              '删除'
	            )
	          ),
	          React.createElement(
	            'a',
	            { href: '#', className: "col-md-8 col-sm-8 col-xs-9 text-right" + (this.state.role === 1 ? ' hide' : '') },
	            '查看'
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = LectureButton;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 573:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var CompleteSection = React.createClass({
	  displayName: 'CompleteSection',

	  getInitialState: function getInitialState() {
	    return {
	      sectionName: '编程题'
	    };
	  },

	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'dashboard-icon col-md-12 col-sm-12 col-xs-12' },
	      React.createElement(
	        'div',
	        { className: 'icon col-md-12 col-sm-12 col-xs-12' },
	        React.createElement(
	          'div',
	          { className: 'icon-img icon-complete' },
	          React.createElement(
	            'span',
	            null,
	            React.createElement('i', { className: 'fa fa-hand-peace-o ' })
	          )
	        ),
	        React.createElement(
	          'p',
	          { className: 'icon-name' },
	          this.state.sectionName
	        )
	      )
	    );
	  }
	});

	module.exports = CompleteSection;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 574:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var LockSection = React.createClass({
	  displayName: "LockSection",


	  render: function render() {
	    return React.createElement(
	      "div",
	      { className: "dashboard-icon col-md-12 col-sm-12 col-xs-12" },
	      React.createElement(
	        "div",
	        { className: "icon col-md-12 col-sm-12 col-xs-12" },
	        React.createElement(
	          "div",
	          { className: "icon-img icon-lock" },
	          React.createElement(
	            "span",
	            null,
	            React.createElement("i", { className: "fa fa-lock text-muted" })
	          )
	        ),
	        React.createElement(
	          "p",
	          { className: "icon-lock-name text-muted" },
	          "请等待管理员解锁"
	        )
	      )
	    );
	  }
	});

	module.exports = LockSection;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 575:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var AddGroup = React.createClass({
	  displayName: "AddGroup",
	  render: function render() {
	    return React.createElement(
	      "div",
	      null,
	      React.createElement(
	        "div",
	        { className: "col-md-3 col-sm-4 col-xs-6 text-center" },
	        React.createElement(
	          "div",
	          { className: "avatar" },
	          React.createElement(
	            "a",
	            { href: "#" },
	            React.createElement(
	              "span",
	              null,
	              React.createElement("i", { className: "fa fa-plus text-success" })
	            )
	          )
	        ),
	        React.createElement(
	          "div",
	          null,
	          React.createElement(
	            "a",
	            { href: "#" },
	            "添加群组"
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = AddGroup;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 576:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 578:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 580:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 582:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 584:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 586:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 588:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 590:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 592:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 594:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 596:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 598:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 600:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 602:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 604:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },

/***/ 606:
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }

});
//# sourceMappingURL=ac1d9a38.style-guide.js.map