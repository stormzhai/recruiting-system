webpackJsonp([4],{

/***/ 251:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = __webpack_require__(252);
	var GroupEvent = __webpack_require__(253);
	var GroupAvatar = __webpack_require__(255);
	var TextBox = __webpack_require__(256);

	var GroupIndex = React.createClass({
	  displayName: "GroupIndex",


	  getInitialState: function getInitialState() {
	    return {
	      announcement: '公告',
	      paperNumber: 8,
	      memberNumber: 35
	    };
	  },

	  render: function render() {
	    return React.createElement(
	      "div",
	      null,
	      React.createElement(
	        "div",
	        { className: "col-md-9" },
	        React.createElement(GroupTitle, { titleName: "群组公告" }),
	        React.createElement(TextBox, { content: this.state.announcement, readonly: true }),
	        React.createElement(GroupTitle, { titleName: "群组事件" }),
	        React.createElement(GroupEvent, null)
	      ),
	      React.createElement(
	        "div",
	        { className: "col-md-3 group-icon" },
	        React.createElement(GroupAvatar, { groupName: "前端学习群", groupAvatar: __webpack_require__(254) }),
	        React.createElement(
	          "p",
	          null,
	          "试卷:",
	          this.state.paperNumber,
	          "张"
	        ),
	        React.createElement(
	          "p",
	          null,
	          "人数:",
	          this.state.memberNumber,
	          "人"
	        )
	      )
	    );
	  }
	});

	module.exports = GroupIndex;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 252:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = React.createClass({
	  displayName: 'GroupTitle',


	  getInitialState: function getInitialState() {
	    return {
	      titleName: this.props.titleName || '群组首页'
	    };
	  },
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'group-title' },
	      React.createElement(
	        'h4',
	        null,
	        this.state.titleName
	      ),
	      React.createElement('hr', null)
	    );
	  }
	});

	module.exports = GroupTitle;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 253:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupEvent = React.createClass({
	  displayName: 'GroupEvent',


	  getInitialState: function getInitialState() {
	    return {
	      items: [{
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'user',
	        time: '04/01/2016 10:22',
	        action: '发布了一条评论',
	        content: '这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难这道题好难'
	      }, {
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'admin',
	        time: '04/01/2016 10:22',
	        action: '增加了一张新试卷 《面向对象 Step By Step》',
	        content: ''
	      }, {
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'user',
	        time: '04/01/2016 10:22',
	        action: '加入了群组',
	        content: ''
	      }, {
	        avatar: __webpack_require__(254),
	        name: '某某某',
	        type: 'user',
	        time: '04/01/2016 10:22',
	        action: '完成了试卷《集合运算》',
	        content: ''
	      }]
	    };
	  },

	  render: function render() {

	    var eventList = this.state.items.map(function (item, index) {
	      return React.createElement(
	        'div',
	        { className: 'col-md-12 col-sm-12 col-xs-12 group-event', key: index },
	        React.createElement(
	          'h5',
	          null,
	          React.createElement(
	            'div',
	            { className: 'user-avatar' },
	            React.createElement('img', { src: item.avatar })
	          ),
	          React.createElement(
	            'div',
	            { className: 'event-info' },
	            React.createElement(
	              'em',
	              null,
	              item.type === 'admin' ? '管理员:' : ''
	            ),
	            item.name,
	            React.createElement(
	              'small',
	              null,
	              item.time
	            ),
	            React.createElement(
	              'span',
	              null,
	              item.action
	            )
	          )
	        ),
	        item.content !== '' ? React.createElement(
	          'p',
	          { className: 'col-md-2 col-sm-4 col-xs-6' },
	          React.createElement(
	            'a',
	            { href: '#' },
	            item.content
	          )
	        ) : null,
	        React.createElement('hr', { className: 'col-md-12 col-sm-12 col-xs-12' })
	      );
	    });

	    return React.createElement(
	      'div',
	      null,
	      eventList
	    );
	  }
	});

	module.exports = GroupEvent;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 254:
/***/ function(module, exports) {

	module.exports = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCACOAJEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6joooqSQooooAY33ao6lf2ml2cl3fzx29tH9+SStCvJvGaP4o+IFloUb/APEu0yP7ZfJ/00k/1dZ1J+zgVE7Xw34s0PxJ5v8AYup214Y/9Ykb/PHXSV87+ILKODxr/wASmeTT9egt/tEF5H/y0j/55yf89K9P+HfjBPElpc2t9B9j1mz/AHd3bfl88fP+rrnw+IVT3SqlP2Z3VFFFdhmFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADT0ryn4Wv9uTXtdfiTU7+ST/ALZ/6uOu18cX39meDda1BB81vaSSR/8AfFcr8P4oND8BW3mSfu4I/wB5XDX+OMTSmcn8TY/7P1K212P/AJcLj/SP+veT/WVjeJ9Rh0LULLXbC7jj1m3/ANXH/wA/cf8Ay0jqidO/4THXdR1W8kkj0afzLeOO3kkj+0R/89K6+1t47eOOOP8A5Zx+XXkYjEU6dXmpnoU6f7s6a0+L3hqeCN5P7Rjkdfnj+wXH7v8A8h1aHxW8IH/j41UWn/XxDJHWJFol9Jb+ZsrOlj8z/WVq84nT+KJn9UpnqOka7pWrx7tL1SzvP+vW4jkraJPbpXgdz4f0ef8A1lhbxyf89I4/Lk/7+VJJqPjDRtMuIPDusR3n7v8Adx6p+8kj/wCucn/xyuihnFOp8RnUwdRHqfinxTpHha3WTU7vZJJ/q7eP5pJP+ucdedal458VaqkcejWtv4fjkk8uOTUB59xJ/wBs657TrSy0uxk1nU3kkvXj8y4vLyTzJK0/AGlz6x4hj13UreS3jjj/ANAt5P8AlnH/AM9JP+mklP65UrP92H1enT/iHU+DNf1eDxGvh/xHdJdXElv9ot7iOPy2/d/6yOSvUB92vLNVj/4vJ4Rf/p3vP/Rdepj7td+H/hnNMWiiiuggKKKKACiiigAooqOWRIYy7sFQUAcj8Vtn/CufEW9tn+gyc+leZ6Jqc+seGvsl9pvl6dJHH/x8f6ySrfivV08a6zbwWknmeHNOk8x5M/u7u4/+Nx1N9K+bzTEe/wCzpnpYOmYOr+J4NHuPsn9mapcf9e9pJJHWSfibpumzRz3lhqlnHHJ/rLi0kr2Dwz4p8OW9lHYz61p6Xtuv7yOS4j8yOrOu+IPBGqaXLaa1q2h3FnJ/rI5rmOuvD5XTqQ9oRUxFQyvBXxD8N+Lf3ejX0cl75fmfZ5P3clUdfjjj1e58v/npVGO88KSW9uPBSWn2e08yPzLOP92Kj/DFefmVT/l2aYen/wAvDo/C2lx3EclxcR+Z/wAs446TxNpsFnHHPbx+Xv8A+WdZUeqalBp8tpptxHbyv/q5JE8zy6xda8IfE+D9/HrGk6x/0zkj8unh8PTxGH9nTHUqezqfvCl4t0P+3NNj8t5I5IJPtEccf/LST/ppXT/B/U77VdFlfVnjkvY5PLkk8jy/LkryvQviNf3F/cWGreHtQt7mD/j48uPzPLr0zwRJHod9q3mSf6Fcf6RHH/00/wCWlaYf2mC/d1gqfvf3lM0rd1vPjTabj/x4aZJIv/bSSOOvVq8k+FkcmoeNfE2s8GCMx2Sf9dP9ZJ/6Mr1uvZwf8M86puFFFFdZAUUUUAFFFFADf4K88+K/iCPR9Hg037D9svdW/wBDt45I/Mj/AO2leiL0rx342W/leIfBl9C7xTfa5LV8Sf8ALPy/M/8AadZ1JcsTSkvfNfwB4Xg0TRLeBI4/Ljj+T93XV3NvHJH5ckf7qotM/eafbv8A9M6uLxXl06fNTOioeSeKPhZY6neSzyWkdx/00riW+E1pDdfvz5cf/TO0jjr6RxxRjPes/YVP+Xcg5zyDRNMtNIs/Is4/Ljq5zXIfHbx7/wAIXr9vY6TYxyXM8fmSeZ/q64GL4x6zbvvvNGs5Iv8AphJXF/ZOIkdn1yme2yeZ5f7v/Wf8s6h8NfGmCPzLTxfptxZ3Vv8Au5J7eMvHn/rn/rErH+Guq23xNt79I1vNLuLD/nnJ/q5K0bXwr/wlVtc/2gkf9o2E8llJJH+7krXB062C0ZnU9nUOstviz4Juvktdet5JpP8Aln5cnmNXJ63p/wDaml3Npv8AL8z/AFcn/POStHRPh3/Z/lmTy5JI/wDl4k/1ldLqXhuOOz8yx8zzY/8AyJVYz2uI/eKIqXs6RH8DUij+HumC3k8yT959pkk/1jXHmfvK9HNeQ/CfUYNP8Q614bkkj8yST+0II/8Arp/rK9fr2sPU9pA8+puFFFFdBAUUUUAFFFFABXmnxuiUeF7fUiiSHS7yO8/7Z/6uT/0ZXpVUdU06DVNPubG8QSW08flyL/erOavoBgeH5I5NFt/L/wCedaZ71598Lbiezj1Hw3qT/wDEx0eTy/8ArpH/AMs5P+/degnvXn0/4ZvUFooorYZ86ftJfDrUtf1KPXdGT7Q0cflyQV83f8I/rX2jyP7Iv/OH/LPyHr9FfL8z/WVGLeCP/lhHWtOuZ+zPGf2avA2peFdL1K+1qH7Pc3/l+XB/y0WOu98GyeZ4q8bSR/6r7fHH/wBtPLjroPEGqJo+k3F3/wA84/3f7ys34f6PcaPoP/Eykjk1K7kkvLjy/wDnpJWUveNDpqKKglkSOOWST/Vx0Aecwyabpvxms0ktd9xf28kcEmzzPs8kf/7yvZWrxX4a2MniTx5q3iS4ubj7JY3H2eyjjk/dySeX+8r2mtsL/DM5/EPoooroMwooooAKKKKACiiigDzD4g+H7+01K38V+HIGuNStI/Lu7Nf+Xy39P9+uh8Paxaa5pMd/psnmRyf+Q6b478VQ+FtI88R/bNQuP3dpZx9Z5K8UsLXxbZ6vc+ILfU0j1W7k8y4t/L/0OT/tn/7Urz8RUp0/4h0U6dSpsfQPaqmpTz29v5lvb+ZJWF4N8QT63byf2lYf2fex/wDLPzPMjk/6511Has/4gHhV5qnxi1WSR7XRY9Ltv+Wcf7vzP/RlZdzpfxek/wBZPef9s7i3r6CuY/Mj8vzPLqn9gf8A5/JPyrU09oeLeDfD+v6xrVzofxGv9aj8yPzLe38yPy54/wDlp/q691ij8uPZHUcWn2keoSX/AJEf22SPy/M/6Z0Xt5aafH5l9cR28f8Az0kk8ukZlojAxXn3jrXJ7q8tvDfh795q13/5Lx/89JKp6v8AEB9fuJNJ8AW8msXv+rkuI/8Aj3j/AOukldl4E8I2/hm1nmmk+2azd/8AH3eSf8tP/saVOnzB7T2ZteFtFtPDuh2em2IHlQR/99f7VblFFeic4UUUUAFFFFABRRXG/EXxOPCnh37asfmXE9xHaQRv/wA9JKAOveVE+8cVn3OrafbxyPNeQL5a7m/eV5l4aj8OeLZ7n+0NSk8SajayfvPtH7uOP/rnH/q6r+LPh/4fj/fw6Lp/lyf6yPy65MRiPZ0+Y0p0/aGTa3cnifVZfEl9/wAt/wB3YR/8+9v/APbK0jzUVjbwWdvHBZxx28cf+rjjqlq+sJZ3FtaW8f2jUbiTy47f/wBqV8pUqVMTUPYpfu6Z0XhuN5NTjeP/AJZ/6yvQRxVDTLJLO38uOtDtmvaweH9lTOOdT2gUUUV3HOZXiHS49YsJIJHuI/8Ann5dxJH/AOi68fuPBekyXBe4g+0SR/8APxJ5n/oyvdR0HrXn3iS3+z6rJ/t/vK8vMHU9n7SmdGHOV0yC78H38uq+Hk8yN/8Aj70//lncR/8ATP8A6aV7boOsWmt6RbalpsvnWVxH5kcleVSj939/y6x9L8MJEDaSXd5cRTz+ZJHJceXH5kn/AEzjrLB5p7On7OoaYjD+0/hnvEWoWsn+ruYG/wC2gq4K84vfDfhLR9JlnvtE02O2gj/eSfZ65vSvGFhpVzH/AGHqMl5o37v7RaXHmSeRHJJ5fmRyf+069+nUPO9me2UUUV0EBRRRQAV5r8b9DuNV8JRy2nniWxu47r/Rz+88sf6yvSqKAPnLwJb6B4fjk1ix1iz+0yR/vJPtH7uP/tnWhd+JvFGqySPaeHtTutF8v/RZI4P9Z/00r1+Tw5oU98t5caLYSXv/AD1kt499b1c9TD06hp7Q+fodP8XarM9tb6Bdafv58+7WMRpVX4R6LHb+Kb2e6k+2Xv2u4jkuJP8Alp5f7uvojoK8I+DRw8skn+t+0XHmf9/JK87EYeOG5fZm9OpUqHsFFFFdZAUUUUAIO1ef/FbT7/8As+PVtJ/eSWn+st/+fiOvQB2rH8Ux+Z4dvf8ArnWNT+GFM8l0TxJaapb+ZHJ/10/6Z1fk8SaXp8kckk8fmR/8s6X4X+CvD/iSPxFdazpsdxcx6n5fmF5I/wDlnHXqXh/wP4b0GTzNH0aztpB/y0WP95XHTyeMv3h0fXDyvxl4jg8UaDLYalb6l4f8z/j3kvI/L+11h/CzTrvVZ7bSdPcyaSnlyX8g/wCXfy5PM8vzP+WnmV9H31nb3kPl3cEU0f8Adkj30ljZ21na+VZ28cEXZI08uvZ9mcftC7RRRW5mFFFFABRRRQAUUUUAJ1FcN4a8DwaHql7d293JILi4kuPL2/c8yu6orOpTU9wM/wDs8/8APQ0f2ef+ehq9u9qTcafskHtCl/Z/+2aP7P8A9s1cp272o9jEPaFD7Ef74qvqWlfbLC4t9/l+ZH5dbNFL2cS/aM5LwL4Tj8LWl7FHcfaPtdz9o3ba62iitCAooooAKKKKACiiigD/2Q=="

/***/ },

/***/ 255:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupAvatar = React.createClass({
	  displayName: 'GroupAvatar',


	  getInitialState: function getInitialState() {
	    return {
	      groupName: this.props.groupName || '前端学习群',
	      groupAvatar: this.props.groupAvatar || ''

	    };
	  },

	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'col-md-12 col-sm-12 col-xs-12 text-center' },
	      React.createElement(
	        'div',
	        { className: 'avatar' },
	        React.createElement(
	          'a',
	          { href: '#' },
	          this.state.groupAvatar !== '' ? React.createElement('img', { src: this.state.groupAvatar }) : React.createElement(
	            'span',
	            null,
	            React.createElement('i', { className: 'fa fa-group' })
	          )
	        )
	      ),
	      React.createElement(
	        'div',
	        { className: 'avatar-name' },
	        React.createElement(
	          'a',
	          { href: '#' },
	          this.state.groupName
	        )
	      )
	    );
	  }
	});

	module.exports = GroupAvatar;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 256:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var TextBox = React.createClass({
	  displayName: 'TextBox',


	  getInitialState: function getInitialState() {
	    return {
	      content: this.props.content
	    };
	  },

	  render: function render() {
	    return React.createElement('textarea', { className: 'textarea',
	      value: this.state.content,
	      readOnly: this.props.readonly ? 'readonly' : '' });
	  }
	});

	module.exports = TextBox;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 257:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = __webpack_require__(258);

	var GroupSidebar = React.createClass({
	  displayName: 'GroupSidebar',
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'col-md-3' },
	      React.createElement(ListGroup, null)
	    );
	  }
	});

	module.exports = GroupSidebar;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 258:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = React.createClass({
	  displayName: 'ListGroup',


	  getInitialState: function getInitialState() {
	    return {
	      title: '个人中心',
	      list: ['群组首页', '群组试卷', '群组成员', '群组管理'],
	      clickNumber: 1
	    };
	  },

	  handleClick: function handleClick(clickNumber) {
	    this.setState({
	      clickNumber: clickNumber
	    });
	  },

	  render: function render() {
	    var _this = this;

	    var listContent = this.state.list.map(function (item, index) {
	      var classStr = "list-group-item " + (_this.state.clickNumber === index + 1 ? 'select' : '');
	      return React.createElement(
	        'button',
	        { className: classStr, key: index, onClick: _this.handleClick.bind(null, index + 1) },
	        React.createElement(
	          'div',
	          { className: 'row' },
	          React.createElement(
	            'div',
	            { className: 'h4 text-center' },
	            item
	          )
	        )
	      );
	    });

	    return React.createElement(
	      'div',
	      null,
	      React.createElement(
	        'div',
	        { className: 'list-group' },
	        React.createElement(
	          'div',
	          { className: 'list-group-item active' },
	          React.createElement(
	            'div',
	            { className: 'row' },
	            React.createElement(
	              'div',
	              { className: 'h4 text-center' },
	              this.state.title
	            )
	          )
	        ),
	        listContent
	      )
	    );
	  }
	});
	module.exports = ListGroup;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ }

});
//# sourceMappingURL=4.3466064d.js.map