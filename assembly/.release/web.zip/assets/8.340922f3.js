webpackJsonp([8],{

/***/ 252:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = React.createClass({
	  displayName: 'GroupTitle',


	  getInitialState: function getInitialState() {
	    return {
	      titleName: this.props.titleName || '群组首页'
	    };
	  },
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'group-title' },
	      React.createElement(
	        'h4',
	        null,
	        this.state.titleName
	      ),
	      React.createElement('hr', null)
	    );
	  }
	});

	module.exports = GroupTitle;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 257:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = __webpack_require__(258);

	var GroupSidebar = React.createClass({
	  displayName: 'GroupSidebar',
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'col-md-3' },
	      React.createElement(ListGroup, null)
	    );
	  }
	});

	module.exports = GroupSidebar;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 258:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = React.createClass({
	  displayName: 'ListGroup',


	  getInitialState: function getInitialState() {
	    return {
	      title: '个人中心',
	      list: ['群组首页', '群组试卷', '群组成员', '群组管理'],
	      clickNumber: 1
	    };
	  },

	  handleClick: function handleClick(clickNumber) {
	    this.setState({
	      clickNumber: clickNumber
	    });
	  },

	  render: function render() {
	    var _this = this;

	    var listContent = this.state.list.map(function (item, index) {
	      var classStr = "list-group-item " + (_this.state.clickNumber === index + 1 ? 'select' : '');
	      return React.createElement(
	        'button',
	        { className: classStr, key: index, onClick: _this.handleClick.bind(null, index + 1) },
	        React.createElement(
	          'div',
	          { className: 'row' },
	          React.createElement(
	            'div',
	            { className: 'h4 text-center' },
	            item
	          )
	        )
	      );
	    });

	    return React.createElement(
	      'div',
	      null,
	      React.createElement(
	        'div',
	        { className: 'list-group' },
	        React.createElement(
	          'div',
	          { className: 'list-group-item active' },
	          React.createElement(
	            'div',
	            { className: 'row' },
	            React.createElement(
	              'div',
	              { className: 'h4 text-center' },
	              this.state.title
	            )
	          )
	        ),
	        listContent
	      )
	    );
	  }
	});
	module.exports = ListGroup;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 264:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = __webpack_require__(252);

	var GroupManage = React.createClass({
	  displayName: "GroupManage",
	  render: function render() {
	    return React.createElement(GroupTitle, { titleName: "群组管理" });
	  }
	});

	module.exports = GroupManage;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ }

});
//# sourceMappingURL=8.340922f3.js.map