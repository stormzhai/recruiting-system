webpackJsonp([9],{

/***/ 252:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = React.createClass({
	  displayName: 'GroupTitle',


	  getInitialState: function getInitialState() {
	    return {
	      titleName: this.props.titleName || '群组首页'
	    };
	  },
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'group-title' },
	      React.createElement(
	        'h4',
	        null,
	        this.state.titleName
	      ),
	      React.createElement('hr', null)
	    );
	  }
	});

	module.exports = GroupTitle;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 265:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = __webpack_require__(252);

	var GroupError = React.createClass({
	  displayName: "GroupError",
	  render: function render() {
	    return React.createElement(GroupTitle, { titleName: "错误页面" });
	  }
	});

	module.exports = GroupError;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ }

});
//# sourceMappingURL=9.9bd0c6b8.js.map