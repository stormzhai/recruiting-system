webpackJsonp([6],{

/***/ 257:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = __webpack_require__(258);

	var GroupSidebar = React.createClass({
	  displayName: 'GroupSidebar',
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'col-md-3' },
	      React.createElement(ListGroup, null)
	    );
	  }
	});

	module.exports = GroupSidebar;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 258:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = React.createClass({
	  displayName: 'ListGroup',


	  getInitialState: function getInitialState() {
	    return {
	      title: '个人中心',
	      list: ['群组首页', '群组试卷', '群组成员', '群组管理'],
	      clickNumber: 1
	    };
	  },

	  handleClick: function handleClick(clickNumber) {
	    this.setState({
	      clickNumber: clickNumber
	    });
	  },

	  render: function render() {
	    var _this = this;

	    var listContent = this.state.list.map(function (item, index) {
	      var classStr = "list-group-item " + (_this.state.clickNumber === index + 1 ? 'select' : '');
	      return React.createElement(
	        'button',
	        { className: classStr, key: index, onClick: _this.handleClick.bind(null, index + 1) },
	        React.createElement(
	          'div',
	          { className: 'row' },
	          React.createElement(
	            'div',
	            { className: 'h4 text-center' },
	            item
	          )
	        )
	      );
	    });

	    return React.createElement(
	      'div',
	      null,
	      React.createElement(
	        'div',
	        { className: 'list-group' },
	        React.createElement(
	          'div',
	          { className: 'list-group-item active' },
	          React.createElement(
	            'div',
	            { className: 'row' },
	            React.createElement(
	              'div',
	              { className: 'h4 text-center' },
	              this.state.title
	            )
	          )
	        ),
	        listContent
	      )
	    );
	  }
	});
	module.exports = ListGroup;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 261:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var DiscussSubject = __webpack_require__(262);

	var GroupDiscussion = React.createClass({
	  displayName: 'GroupDiscussion',
	  render: function render() {
	    return React.createElement(DiscussSubject, null);
	  }
	});

	module.exports = GroupDiscussion;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 262:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var DiscussSubject = React.createClass({
	  displayName: 'DiscussSubject',

	  getInitialState: function getInitialState() {
	    return {
	      subjectList: [{
	        isMe: true,
	        userName: '某某某',
	        time: '04/01/2016 10:22',
	        subject: '阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科阿里的罚金老师的罚款了世界的科'
	      }, {
	        isMe: false,
	        userName: '某某某',
	        time: '04/01/2016 10:22',
	        subject: '阿里的罚金老师的罚款了世界的科'
	      }]
	    };
	  },
	  render: function render() {

	    var subjectList = this.state.subjectList.map(function (item, index) {
	      var operateCls = "operate col-md-2 col-sm-2 col-xs-2" + (item.isMe ? '' : ' unvisible');
	      return React.createElement(
	        'div',
	        { className: 'discuss-subject col-md-12 col-sm-12 col-xs-12', key: index },
	        React.createElement(
	          'div',
	          { className: 'content col-md-10 col-sm-10 col-xs-10' },
	          React.createElement(
	            'h5',
	            { className: 'col-md-12 col-sm-12 col-xs-12' },
	            item.isMe ? '我' : item.userName,
	            React.createElement(
	              'small',
	              null,
	              item.time
	            )
	          ),
	          React.createElement(
	            'p',
	            { className: 'col-md-10 col-sm-9 col-xs-6' },
	            React.createElement(
	              'a',
	              null,
	              item.subject
	            )
	          )
	        ),
	        React.createElement(
	          'div',
	          { className: operateCls },
	          React.createElement(
	            'a',
	            { href: '#' },
	            '编辑'
	          ),
	          React.createElement(
	            'a',
	            { href: '#' },
	            '删除'
	          )
	        ),
	        React.createElement('hr', { className: 'col-md-12 col-sm-12 col-xs-12' })
	      );
	    });
	    return React.createElement(
	      'div',
	      null,
	      subjectList
	    );
	  }
	});

	module.exports = DiscussSubject;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ }

});
//# sourceMappingURL=6.85e50f01.js.map