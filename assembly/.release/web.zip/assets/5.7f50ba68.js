webpackJsonp([5],{

/***/ 252:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = React.createClass({
	  displayName: 'GroupTitle',


	  getInitialState: function getInitialState() {
	    return {
	      titleName: this.props.titleName || '群组首页'
	    };
	  },
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'group-title' },
	      React.createElement(
	        'h4',
	        null,
	        this.state.titleName
	      ),
	      React.createElement('hr', null)
	    );
	  }
	});

	module.exports = GroupTitle;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 257:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = __webpack_require__(258);

	var GroupSidebar = React.createClass({
	  displayName: 'GroupSidebar',
	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'col-md-3' },
	      React.createElement(ListGroup, null)
	    );
	  }
	});

	module.exports = GroupSidebar;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 258:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var ListGroup = React.createClass({
	  displayName: 'ListGroup',


	  getInitialState: function getInitialState() {
	    return {
	      title: '个人中心',
	      list: ['群组首页', '群组试卷', '群组成员', '群组管理'],
	      clickNumber: 1
	    };
	  },

	  handleClick: function handleClick(clickNumber) {
	    this.setState({
	      clickNumber: clickNumber
	    });
	  },

	  render: function render() {
	    var _this = this;

	    var listContent = this.state.list.map(function (item, index) {
	      var classStr = "list-group-item " + (_this.state.clickNumber === index + 1 ? 'select' : '');
	      return React.createElement(
	        'button',
	        { className: classStr, key: index, onClick: _this.handleClick.bind(null, index + 1) },
	        React.createElement(
	          'div',
	          { className: 'row' },
	          React.createElement(
	            'div',
	            { className: 'h4 text-center' },
	            item
	          )
	        )
	      );
	    });

	    return React.createElement(
	      'div',
	      null,
	      React.createElement(
	        'div',
	        { className: 'list-group' },
	        React.createElement(
	          'div',
	          { className: 'list-group-item active' },
	          React.createElement(
	            'div',
	            { className: 'row' },
	            React.createElement(
	              'div',
	              { className: 'h4 text-center' },
	              this.state.title
	            )
	          )
	        ),
	        listContent
	      )
	    );
	  }
	});
	module.exports = ListGroup;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 259:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var GroupTitle = __webpack_require__(252);
	var Paper = __webpack_require__(260);

	var GroupPapers = React.createClass({
	  displayName: "GroupPapers",

	  getInitialState: function getInitialState() {
	    return {
	      noticedPapers: [{
	        paperName: 'pos 无尽版',
	        isMarked: true,
	        isPublished: true,
	        sectionNumber: 13,
	        publishedNumber: 6,
	        role: '2',
	        isFinished: false
	      }, {
	        paperName: 'pos 真·无尽版',
	        isMarked: true,
	        isPublished: true,
	        sectionNumber: 13,
	        publishedNumber: 6,
	        role: '2',
	        isFinished: false
	      }],
	      unfinishedList: [{
	        paperName: 'pos v_3.0',
	        isMarked: false,
	        isPublished: true,
	        sectionNumber: 9,
	        publishedNumber: 4,
	        role: '2',
	        isFinished: false
	      }, {
	        paperName: 'pos v_2.0',
	        isMarked: false,
	        isPublished: true,
	        sectionNumber: 10,
	        publishedNumber: 5,
	        role: '2',
	        isFinished: false
	      }],
	      finishedList: [{
	        paperName: 'pos v_0.0',
	        isMarked: false,
	        isPublished: true,
	        sectionNumber: 9,
	        publishedNumber: 9,
	        role: '2',
	        isFinished: true
	      }, {
	        paperName: 'pos v_1.0',
	        isMarked: false,
	        isPublished: true,
	        sectionNumber: 10,
	        publishedNumber: 10,
	        role: '2',
	        isFinished: true
	      }]
	    };
	  },

	  render: function render() {

	    var noticedList = this.state.noticedPapers.map(function (item, index) {
	      return React.createElement(Paper, { item: item, key: index });
	    });
	    var unfinishedList = this.state.unfinishedList.map(function (item, index) {
	      return React.createElement(Paper, { item: item, key: index });
	    });
	    var finishedList = this.state.finishedList.map(function (item, index) {
	      return React.createElement(Paper, { item: item, key: index });
	    });

	    return React.createElement(
	      "div",
	      { className: "col-md-12 col-sm-12 col-xs-12" },
	      React.createElement(GroupTitle, { titleName: "我关注的试卷" }),
	      React.createElement(
	        "div",
	        { className: "col-md-12 col-sm-12 col-xs-12" },
	        noticedList
	      ),
	      React.createElement(GroupTitle, { titleName: "未完成的试卷" }),
	      React.createElement(
	        "div",
	        { className: "col-md-12 col-sm-12 col-xs-12" },
	        unfinishedList
	      ),
	      React.createElement(GroupTitle, { titleName: "已完成的试卷" }),
	      React.createElement(
	        "div",
	        { className: "col-md-12 col-sm-12 col-xs-12" },
	        finishedList
	      )
	    );
	  }
	});

	module.exports = GroupPapers;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ },

/***/ 260:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(React) {'use strict';

	var Paper = React.createClass({
	  displayName: 'Paper',
	  getInitialState: function getInitialState() {
	    return {
	      paperName: this.props.item.paperName || 'PaperNamePaperName',
	      isMarked: this.props.item.isMarked,
	      isPublished: this.props.item.isPublished,
	      sectionNumber: this.props.item.sectionNumber || 10,
	      publishedNumber: this.props.item.publishedNumber || 1,
	      role: this.props.item.role || '2',
	      isFinished: this.props.item.isFinished
	    };
	  },

	  render: function render() {
	    return React.createElement(
	      'div',
	      { className: 'paper-button col-xs-12' },
	      React.createElement(
	        'h3',
	        { className: 'paper-name col-xs-9' },
	        this.state.paperName
	      ),
	      React.createElement(
	        'div',
	        { className: 'col-xs-3' },
	        React.createElement('i', { className: "fa fa-2x" + (this.state.isMarked ? ' fa-star' : ' fa-star-o') })
	      ),
	      React.createElement(
	        'div',
	        { className: "col-md-9 col-sm-5" + (this.state.role === '1' ? '' : ' hide') },
	        React.createElement(
	          'div',
	          { className: this.state.isPublished ? 'hide' : '' },
	          '未发布：',
	          React.createElement(
	            'a',
	            { href: '#' },
	            '点击发布'
	          )
	        ),
	        React.createElement(
	          'div',
	          { className: this.state.isPublished ? '' : ' hide' },
	          '已发布'
	        ),
	        React.createElement(
	          'div',
	          null,
	          '章节个数：',
	          this.state.sectionNumber
	        ),
	        React.createElement(
	          'div',
	          null,
	          '已发布个数：',
	          this.state.publishedNumber
	        )
	      ),
	      React.createElement(
	        'div',
	        { className: 'button-bottom' },
	        React.createElement(
	          'a',
	          { href: '#', className: "text-warning" + (this.state.role === '1' ? '' : ' unvisible') },
	          React.createElement(
	            'b',
	            null,
	            '编辑'
	          )
	        ),
	        React.createElement(
	          'a',
	          { href: '#', className: "text-info" + (this.state.role === '1' ? '' : ' unvisible') },
	          React.createElement(
	            'b',
	            null,
	            '导出成绩'
	          )
	        ),
	        React.createElement(
	          'a',
	          { href: '#', className: "text-success" + (this.state.isFinished ? ' unvisible' : '') },
	          React.createElement(
	            'b',
	            null,
	            '开始答题'
	          )
	        )
	      )
	    );
	  }
	});

	module.exports = Paper;
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(165)))

/***/ }

});
//# sourceMappingURL=5.7f50ba68.js.map