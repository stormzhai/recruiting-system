'use strict';

beforeAll(function() {
  console.log('Start!!!');
});