'use strict';

var lang = {
  ERROR: '旧密码错误',
  REGISTER_SUCCESS: '注册成功！5秒后跳转至答题页面。',
  REGISTER_FAILED: '注册失败,注册信息有误。',
  EXIST: '手机号或者邮箱已被注册',
  LOGIN_FAILED: '登录失败',
  CONFIRM_ERROR:'两次密码不匹配'
};

module.exports = lang;
